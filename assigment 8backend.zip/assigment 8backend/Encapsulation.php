<?php
class Book {
    private $title;
    private $author;
    private $bookId;

    public function __construct($title, $author, $bookId) {
        $this->title = $title;
        $this->author = $author;
        $this->bookId = $bookId;
    }

    // Getter methods
    public function getTitle() {
        return $this->title;
    }

    public function getAuthor() {
        return $this->author;
    }

    public function getBookId() {
        return $this->bookId;
    }

    // Setter methods
    public function setTitle($title) {
        $this->title = $title;
    }

    public function setAuthor($author) {
        $this->author = $author;
    }

    public function setBookId($bookId) {
        $this->bookId = $bookId;
    }
}

// Example usage
$book = new Book("The Great Gatsby", "F. Scott Fitzgerald", 1);
echo $book->getTitle(); // Output: The Great Gatsby
$book->setTitle("1984");
echo $book->getTitle(); // Output: 1984
?>
